const API_URL ="https://fakestoreapi.com/products"


export default API_URL;